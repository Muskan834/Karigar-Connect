import { FormEvent, useEffect, useMemo, useState } from "react";

type IconName =
  | "arrow"
  | "bell"
  | "briefcase"
  | "check"
  | "chevron"
  | "close"
  | "comment"
  | "connect"
  | "dashboard"
  | "download"
  | "globe"
  | "heart"
  | "home"
  | "identity"
  | "like"
  | "location"
  | "menu"
  | "message"
  | "mic"
  | "network"
  | "offline"
  | "people"
  | "plus"
  | "qr"
  | "search"
  | "settings"
  | "share"
  | "spark"
  | "star"
  | "store"
  | "target"
  | "user"
  | "voice"
  | "wallet"
  | "wifi";

const photos = {
  potter:
    "https://images.unsplash.com/photo-1698768195616-2d49cb36477f?auto=format&fit=crop&w=1200&q=85",
  pottery:
    "https://images.unsplash.com/photo-1524497440-4da55062cb4a?auto=format&fit=crop&w=900&q=85",
  tailor:
    "https://images.unsplash.com/photo-1772333388975-6c5b969d7a2b?auto=format&fit=crop&w=900&q=85",
  weaver:
    "https://images.unsplash.com/photo-1601056639638-c53c50e13ead?auto=format&fit=crop&w=1000&q=85",
  jewellery:
    "https://images.unsplash.com/photo-1712166424521-c92105147d7b?auto=format&fit=crop&w=900&q=85",
  carpenter:
    "https://images.unsplash.com/photo-1645597454479-14cb0e8bcabe?auto=format&fit=crop&w=900&q=85",
  professional:
    "https://images.unsplash.com/photo-1631613491628-483fb6972aff?auto=format&fit=crop&w=900&q=85",
  clay: "https://images.unsplash.com/photo-1678296728930-775d299daaca?auto=format&fit=crop&w=1000&q=85",
};

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, React.ReactNode> = {
    arrow: (
      <>
        <path d="M5 12h14" />
        <path d="m13 6 6 6-6 6" />
      </>
    ),
    bell: (
      <>
        <path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9" />
        <path d="M10 21h4" />
      </>
    ),
    briefcase: (
      <>
        <rect x="3" y="7" width="18" height="13" rx="2" />
        <path d="M8 7V4h8v3M3 12h18M10 12v2h4v-2" />
      </>
    ),
    check: <path d="m5 12 4 4L19 6" />,
    chevron: <path d="m9 18 6-6-6-6" />,
    close: (
      <>
        <path d="m6 6 12 12M18 6 6 18" />
      </>
    ),
    comment: <path d="M20 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h9a4 4 0 0 1 4 4Z" />,
    connect: (
      <>
        <circle cx="7" cy="7" r="3" />
        <circle cx="17" cy="17" r="3" />
        <path d="m9.5 9.5 5 5M14 5h5v5" />
      </>
    ),
    dashboard: (
      <>
        <rect x="3" y="3" width="7" height="7" rx="1" />
        <rect x="14" y="3" width="7" height="7" rx="1" />
        <rect x="3" y="14" width="7" height="7" rx="1" />
        <rect x="14" y="14" width="7" height="7" rx="1" />
      </>
    ),
    download: (
      <>
        <path d="M12 3v12m-4-4 4 4 4-4" />
        <path d="M5 19h14" />
      </>
    ),
    globe: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18" />
      </>
    ),
    heart: (
      <path d="M20.8 5.8a5.2 5.2 0 0 0-7.4 0L12 7.2l-1.4-1.4a5.2 5.2 0 0 0-7.4 7.4L12 22l8.8-8.8a5.2 5.2 0 0 0 0-7.4Z" />
    ),
    home: (
      <>
        <path d="m3 11 9-8 9 8" />
        <path d="M5 10v10h14V10M10 20v-6h4v6" />
      </>
    ),
    identity: (
      <>
        <rect x="3" y="5" width="18" height="14" rx="2" />
        <circle cx="9" cy="11" r="2.5" />
        <path d="M5.5 17c.7-2 2-3 3.5-3s2.8 1 3.5 3M15 9h4M15 13h4" />
      </>
    ),
    like: (
      <>
        <path d="M7 10v11H3V10h4Z" />
        <path d="M7 19h9a3 3 0 0 0 3-2.4l1.1-5A3 3 0 0 0 17.2 8H14l1-4.2A1.5 1.5 0 0 0 12.2 3L7 10" />
      </>
    ),
    location: (
      <>
        <path d="M20 10c0 5-8 12-8 12S4 15 4 10a8 8 0 1 1 16 0Z" />
        <circle cx="12" cy="10" r="2.5" />
      </>
    ),
    menu: (
      <>
        <path d="M4 7h16M4 12h16M4 17h16" />
      </>
    ),
    message: (
      <>
        <path d="M20 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h9a4 4 0 0 1 4 4Z" />
        <path d="M7 9h10M7 13h7" />
      </>
    ),
    mic: (
      <>
        <rect x="9" y="3" width="6" height="11" rx="3" />
        <path d="M5 11a7 7 0 0 0 14 0M12 18v3M9 21h6" />
      </>
    ),
    network: (
      <>
        <circle cx="12" cy="5" r="3" />
        <circle cx="5" cy="18" r="3" />
        <circle cx="19" cy="18" r="3" />
        <path d="m10.5 7.7-4 7.6M13.5 7.7l4 7.6M8 18h8" />
      </>
    ),
    offline: (
      <>
        <path d="M5 12.5a10 10 0 0 1 13.5-.5M8.5 16a5 5 0 0 1 5.5-.8M12 20h.01M3 3l18 18" />
      </>
    ),
    people: (
      <>
        <circle cx="8" cy="8" r="3" />
        <circle cx="17" cy="9" r="2.5" />
        <path d="M2.5 20a5.5 5.5 0 0 1 11 0M14 16a4.5 4.5 0 0 1 7 4" />
      </>
    ),
    plus: <path d="M12 5v14M5 12h14" />,
    qr: (
      <>
        <path d="M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h3v3h-3zM19 14h2v2M14 19h2v2M19 19h2v2" />
      </>
    ),
    search: (
      <>
        <circle cx="11" cy="11" r="7" />
        <path d="m20 20-4-4" />
      </>
    ),
    settings: (
      <>
        <circle cx="12" cy="12" r="3" />
        <path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1A1.7 1.7 0 0 0 9 4.6a1.7 1.7 0 0 0 1-1.6v-.2h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z" />
      </>
    ),
    share: (
      <>
        <circle cx="18" cy="5" r="2.5" />
        <circle cx="6" cy="12" r="2.5" />
        <circle cx="18" cy="19" r="2.5" />
        <path d="m8.3 10.9 7.4-4.3M8.3 13.1l7.4 4.3" />
      </>
    ),
    spark: (
      <>
        <path d="m12 2 1.7 5.3L19 9l-5.3 1.7L12 16l-1.7-5.3L5 9l5.3-1.7Z" />
        <path d="m19 16 .8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8Z" />
      </>
    ),
    star: <path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9Z" />,
    store: (
      <>
        <path d="M4 10v10h16V10M3 4h18l-2 6H5Z" />
        <path d="M9 20v-6h6v6" />
      </>
    ),
    target: (
      <>
        <circle cx="12" cy="12" r="9" />
        <circle cx="12" cy="12" r="5" />
        <circle cx="12" cy="12" r="1" />
      </>
    ),
    user: (
      <>
        <circle cx="12" cy="8" r="4" />
        <path d="M4 21a8 8 0 0 1 16 0" />
      </>
    ),
    voice: (
      <>
        <path d="M4 10v4M8 7v10M12 4v16M16 7v10M20 10v4" />
      </>
    ),
    wallet: (
      <>
        <path d="M4 6h15a2 2 0 0 1 2 2v10H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h12" />
        <path d="M16 11h5v4h-5a2 2 0 0 1 0-4Z" />
      </>
    ),
    wifi: (
      <>
        <path d="M4 10a12 12 0 0 1 16 0M7 14a7.5 7.5 0 0 1 10 0M10.5 17.5a2.5 2.5 0 0 1 3 0M12 21h.01" />
      </>
    ),
  };
  return (
    <svg
      aria-hidden="true"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.75"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name]}
    </svg>
  );
}

function useRoute() {
  const read = () => window.location.hash.replace("#/", "") || "home";
  const [route, setRoute] = useState(read);
  useEffect(() => {
    const update = () => {
      setRoute(read());
      window.scrollTo({ top: 0 });
    };
    window.addEventListener("hashchange", update);
    return () => window.removeEventListener("hashchange", update);
  }, []);
  return route;
}

function Logo({ light = false }: { light?: boolean }) {
  return (
    <a className={`logo ${light ? "light" : ""}`} href="#/home" aria-label="Karigar Connect home">
      <span className="logo-symbol">K</span>
      <span>
        KARIGAR <b>CONNECT</b>
      </span>
    </a>
  );
}

const mainNav = [
  ["home", "Home"],
  ["discover", "Discover Professionals"],
  ["network", "Networking"],
  ["buying", "Collective Buying"],
  ["voice", "Voice Assistant"],
];

function Header({
  route,
  loggedIn,
  online,
  toggleOnline,
}: {
  route: string;
  loggedIn: boolean;
  online: boolean;
  toggleOnline: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  useEffect(() => {
    setOpen(false);
    setProfileOpen(false);
  }, [route]);
  return (
    <header className="site-header">
      <div className="nav-shell">
        <Logo />
        <nav className={`nav-links ${open ? "show" : ""}`} aria-label="Main navigation">
          {mainNav.map(([path, label]) => (
            <a key={path} className={route.startsWith(path) ? "active" : ""} href={`#/${path}`}>
              {label}
            </a>
          ))}
          <div className="mobile-nav-actions">
            {loggedIn ? (
              <a className="button primary" href="#/dashboard">
                My dashboard
              </a>
            ) : (
              <>
                <a href="#/login">Login</a>
                <a className="button primary" href="#/join">
                  Join now
                </a>
              </>
            )}
          </div>
        </nav>
        <div className="nav-actions">
          <button className={`status-pill ${online ? "" : "offline"}`} onClick={toggleOnline}>
            <Icon name={online ? "wifi" : "offline"} size={14} />
            {online ? "Online" : "Offline"}
          </button>
          {loggedIn ? (
            <>
              <a href="#/messages" className="nav-icon" aria-label="Messages">
                <Icon name="message" size={19} />
                <i></i>
              </a>
              <a href="#/notifications" className="nav-icon" aria-label="Notifications">
                <Icon name="bell" size={19} />
                <i></i>
              </a>
              <button className="profile-trigger" onClick={() => setProfileOpen(!profileOpen)}>
                <img src={photos.professional} alt="" />
                <span>Rahul</span>
                <Icon name="chevron" size={14} />
              </button>
              {profileOpen && (
                <div className="profile-menu">
                  <strong>Rahul Sharma</strong>
                  <small>Master Tailor · Delhi</small>
                  <a href="#/dashboard">My dashboard</a>
                  <a href="#/identity">Digital identity</a>
                  <a href="#/profile/rahul">View profile</a>
                </div>
              )}
            </>
          ) : (
            <>
              <a className="login-link" href="#/login">
                Login
              </a>
              <a className="button primary compact" href="#/join">
                Join now <Icon name="arrow" size={16} />
              </a>
            </>
          )}
        </div>
        <button className="menu-toggle" onClick={() => setOpen(!open)} aria-label="Toggle menu">
          <Icon name={open ? "close" : "menu"} size={25} />
        </button>
      </div>
    </header>
  );
}

function Eyebrow({ children, light = false }: { children: React.ReactNode; light?: boolean }) {
  return (
    <div className={`eyebrow ${light ? "light" : ""}`}>
      <span></span>
      {children}
    </div>
  );
}

function Button({
  href,
  children,
  secondary = false,
}: {
  href: string;
  children: React.ReactNode;
  secondary?: boolean;
}) {
  return (
    <a className={`button ${secondary ? "secondary" : "primary"}`} href={href}>
      {children}
      <Icon name="arrow" size={17} />
    </a>
  );
}

function QRCode({ size = 150 }: { size?: number }) {
  const data = `${window.location.origin}${window.location.pathname}#/profile/rahul`;
  return (
    <a href="#/profile/rahul" className="qr-wrap" aria-label="Open Rahul Sharma's sample profile">
      <img
        width={size}
        height={size}
        src={`https://api.qrserver.com/v1/create-qr-code/?size=${size * 2}x${size * 2}&data=${encodeURIComponent(data)}&color=173c2a&bgcolor=ffffff&margin=8`}
        alt="Scannable QR code for Rahul Sharma's sample profile"
      />
    </a>
  );
}

function IdentityCard({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`identity-card ${compact ? "compact-card" : ""}`}>
      <div className="id-top">
        <Logo light />
        <span>
          <Icon name="check" size={13} /> Mobile verified
        </span>
      </div>
      <div className="id-body">
        <img className="id-photo" src={photos.professional} alt="Rahul Sharma" />
        <div className="id-person">
          <small>PROFESSIONAL IDENTITY</small>
          <h3>Rahul Sharma</h3>
          <p>Master Tailor · 12 years</p>
          <span>
            <Icon name="location" size={13} /> Lajpat Nagar, Delhi
          </span>
        </div>
        <QRCode size={compact ? 80 : 105} />
      </div>
      <div className="id-skills">
        <span>Men's tailoring</span>
        <span>Custom suits</span>
        <span>Alterations</span>
      </div>
      <div className="id-number">
        <span>KC ID</span> KC-DL-04821 <small>Scan to view verified professional profile</small>
      </div>
    </div>
  );
}

function Home() {
  const problems = [
    [
      "identity",
      "No professional identity",
      "Skill and experience remain invisible beyond a local neighbourhood.",
    ],
    [
      "wallet",
      "Limited buying power",
      "Small individual orders rarely qualify for true wholesale rates.",
    ],
    [
      "network",
      "Few B2B connections",
      "Finding trusted suppliers and collaborators depends on word of mouth.",
    ],
    [
      "voice",
      "Digital barriers",
      "Complex interfaces and language gaps keep opportunity out of reach.",
    ],
  ] as [IconName, string, string][];
  return (
    <main>
      <section className="home-hero">
        <div className="hero-orbit orbit-a"></div>
        <div className="hero-orbit orbit-b"></div>
        <div className="container hero-layout">
          <div className="hero-copy">
            <Eyebrow>India's professional network for skilled businesses</Eyebrow>
            <h1>
              Your skills are your identity. <em>Your network is your strength.</em>
            </h1>
            <p>
              Build your professional identity, connect with businesses, buy raw materials together
              at wholesale prices and grow with India's digital network for skilled professionals.
            </p>
            <div className="hero-actions">
              <Button href="#/join">Create your digital identity</Button>
              <Button href="#/discover" secondary>
                Explore professional network
              </Button>
            </div>
            <div className="trust-row">
              <div className="mini-avatars">
                {[photos.tailor, photos.pottery, photos.carpenter, photos.jewellery].map((p, i) => (
                  <img key={i} src={p} alt="" />
                ))}
              </div>
              <span>
                <strong>2,400+ professionals</strong>
                <small>Building stronger businesses together</small>
              </span>
            </div>
          </div>
          <div className="hero-visual">
            <div className="hero-main-photo">
              <img src={photos.potter} alt="Indian artisan at work in her pottery studio" />
            </div>
            <div className="float-card qr-float">
              <span className="float-icon">
                <Icon name="qr" />
              </span>
              <div>
                <small>QR DIGITAL IDENTITY</small>
                <strong>Profile verified</strong>
              </div>
            </div>
            <div className="float-card people-float">
              <div className="mini-avatars">
                {[photos.professional, photos.tailor, photos.carpenter].map((p, i) => (
                  <img key={i} src={p} alt="" />
                ))}
              </div>
              <div>
                <small>YOUR NETWORK</small>
                <strong>120+ nearby professionals</strong>
              </div>
            </div>
            <div className="float-card group-float">
              <span className="float-icon mustard">
                <Icon name="wallet" />
              </span>
              <div>
                <small>WHOLESALE FABRIC GROUP</small>
                <strong>70% of target reached</strong>
                <i>
                  <b></b>
                </i>
              </div>
            </div>
            <div className="float-card connection-float">
              <span className="online-dot"></span>
              <div>
                <small>NEW CONNECTION</small>
                <strong>Suresh Textiles</strong>
              </div>
            </div>
          </div>
        </div>
      </section>
      <div className="promise-bar">
        <span>PROFESSIONAL IDENTITY</span>
        <i></i>
        <span>BUSINESS NETWORK</span>
        <i></i>
        <span>COLLECTIVE BUYING</span>
        <i></i>
        <span>YOUR LANGUAGE</span>
      </div>

      <section className="section problems">
        <div className="container">
          <div className="section-heading split">
            <div>
              <Eyebrow>Why Karigar Connect</Eyebrow>
              <h2>
                Skilled hands.
                <br />
                <em>Limited connections.</em>
              </h2>
            </div>
            <p>
              India's informal workforce powers the economy, yet millions of capable professionals
              remain disconnected from the tools, networks and purchasing power that businesses need
              to grow.
            </p>
          </div>
          <div className="problem-grid">
            {problems.map(([icon, title, text], i) => (
              <article key={title}>
                <span className="number">0{i + 1}</span>
                <span className="problem-icon">
                  <Icon name={icon} size={25} />
                </span>
                <h3>{title}</h3>
                <p>{text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="community-solution section">
        <div className="container solution-layout">
          <div className="solution-photo">
            <img src={photos.carpenter} alt="Indian carpenter working in his workshop" />
            <span className="solution-stat">
              <strong>4×</strong>
              <small>more opportunity through stronger networks</small>
            </span>
          </div>
          <div className="solution-copy">
            <Eyebrow light>One connected ecosystem</Eyebrow>
            <h2>
              Meet your digital
              <br />
              <em>business community.</em>
            </h2>
            <p>
              KARIGAR CONNECT combines professional identity, business networking, collective
              purchasing and multilingual support in one simple platform designed around the way you
              work.
            </p>
            <ul>
              {[
                "Be recognised as a professional",
                "Meet trusted business connections",
                "Build collective purchasing power",
                "Use technology in your own language",
              ].map((x) => (
                <li key={x}>
                  <span>
                    <Icon name="check" size={14} />
                  </span>
                  {x}
                </li>
              ))}
            </ul>
            <Button href="#/join">Join the community</Button>
          </div>
        </div>
      </section>

      <section className="section feature-showcase identity-showcase">
        <div className="container feature-layout">
          <div className="feature-copy">
            <span className="feature-count">01 · DIGITAL IDENTITY</span>
            <Eyebrow>Proof of who you are</Eyebrow>
            <h2>
              Every karigar deserves a <em>professional identity.</em>
            </h2>
            <p>
              A verified, shareable digital card turns your experience into a professional presence.
              Customers, suppliers and collaborators can scan your QR code to see your skills,
              portfolio, location and credentials.
            </p>
            <div className="mini-features">
              <span>
                <Icon name="qr" /> Unique QR profile
              </span>
              <span>
                <Icon name="check" /> Verification status
              </span>
              <span>
                <Icon name="share" /> Easy sharing
              </span>
              <span>
                <Icon name="briefcase" /> Work portfolio
              </span>
            </div>
            <Button href="#/identity">Explore digital identity</Button>
          </div>
          <div className="identity-stage">
            <IdentityCard compact />
            <div className="scan-note">
              <span>
                <Icon name="qr" size={26} />
              </span>
              <div>
                <strong>Scan. Verify. Connect.</strong>
                <small>One identity across every opportunity</small>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="section buying-showcase">
        <div className="container feature-layout reverse">
          <div className="buying-preview">
            <div className="preview-head">
              <span className="material-icon">
                <Icon name="store" size={24} />
              </span>
              <div>
                <small>ACTIVE BUYING GROUP</small>
                <strong>Wholesale Cotton Fabric</strong>
                <span>Delhi · Closes in 4 days</span>
              </div>
              <b>70%</b>
            </div>
            <div className="big-progress">
              <i style={{ width: "70%" }}></i>
            </div>
            <div className="progress-labels">
              <span>
                <strong>350 m</strong> committed
              </span>
              <span>
                <strong>500 m</strong> target
              </span>
            </div>
            <div className="price-row">
              <span>
                Wholesale estimate<strong>₹85/m</strong>
              </span>
              <span>
                Retail comparison<strong className="strike">₹110/m</strong>
              </span>
              <span className="saving">
                You save<strong>₹25/m</strong>
              </span>
            </div>
            <div className="participant-row">
              <div className="mini-avatars">
                {[photos.professional, photos.tailor, photos.weaver].map((p, i) => (
                  <img key={i} src={p} alt="" />
                ))}
                <b>+5</b>
              </div>
              <span>8 tailors have joined</span>
              <button>View group</button>
            </div>
            <small className="estimate-note">Illustrative price estimates only</small>
          </div>
          <div className="feature-copy">
            <span className="feature-count">02 · COLLECTIVE BUYING</span>
            <Eyebrow>Strength in numbers</Eyebrow>
            <h2>
              Buy together.
              <br />
              <em>Save together.</em>
            </h2>
            <p>
              Combine your material needs with nearby businesses, meet supplier minimums and unlock
              wholesale rates that would be impossible alone.
            </p>
            <div className="material-chips">
              <span>Fabric</span>
              <span>Yarn</span>
              <span>Clay</span>
              <span>Ingredients</span>
              <span>Packaging</span>
            </div>
            <Button href="#/buying">Explore buying groups</Button>
          </div>
        </div>
      </section>

      <section className="section network-showcase">
        <div className="container feature-layout">
          <div className="feature-copy">
            <span className="feature-count">03 · B2B NETWORKING</span>
            <Eyebrow>Your professional circle</Eyebrow>
            <h2>
              Build connections.
              <br />
              <em>Build your business.</em>
            </h2>
            <p>
              Find suppliers, collaborators and opportunities in a serious professional network
              created for India's skilled economy—not social entertainment.
            </p>
            <ul className="check-list">
              <li>
                <Icon name="check" size={14} />
                Showcase completed projects
              </li>
              <li>
                <Icon name="check" size={14} />
                Post collaboration requirements
              </li>
              <li>
                <Icon name="check" size={14} />
                Connect with verified suppliers
              </li>
            </ul>
            <Button href="#/network">Open business network</Button>
          </div>
          <div className="feed-preview">
            <div className="post-mini">
              <div className="post-author">
                <img src={photos.professional} alt="" />
                <span>
                  <strong>Rahul Sharma</strong>
                  <small>Master Tailor · Delhi · 2h</small>
                </span>
                <b>Verified</b>
              </div>
              <p>Looking for a reliable fabric supplier in Delhi for regular bulk purchases.</p>
              <span className="post-tag">#SupplierRequired</span>
              <div className="post-actions">
                <span>
                  <Icon name="like" size={16} /> 18
                </span>
                <span>
                  <Icon name="comment" size={16} /> 6 comments
                </span>
                <button>Connect</button>
              </div>
            </div>
            <div className="suggestion-mini">
              <small>SUGGESTED CONNECTION</small>
              <div>
                <img src={photos.weaver} alt="" />
                <span>
                  <strong>Meera Patil</strong>
                  <small>Textile Designer · Pune</small>
                </span>
                <button>
                  <Icon name="plus" size={15} /> Connect
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="section voice-showcase">
        <div className="container feature-layout reverse">
          <div className="voice-device">
            <div className="device-top">
              <span>
                <Icon name="voice" size={18} /> Karigar Sahayak
              </span>
              <span>
                हिंदी <Icon name="chevron" size={13} />
              </span>
            </div>
            <div className="voice-conversation">
              <div className="user-bubble">“Mere paas cotton fabric supplier dhundo.”</div>
              <div className="assistant-bubble">
                <span>
                  <Icon name="spark" size={17} />
                </span>
                <p>
                  I found three cotton fabric suppliers near you. Would you like to see their
                  profiles?
                </p>
              </div>
            </div>
            <div className="wave-bars">
              {[12, 22, 31, 18, 38, 25, 16, 29, 19, 34, 14].map((h, i) => (
                <i key={i} style={{ height: h }}></i>
              ))}
            </div>
            <button className="mic-button">
              <Icon name="mic" size={30} />
            </button>
            <small>Tap to speak · Prototype simulation</small>
          </div>
          <div className="feature-copy">
            <span className="feature-count">04 · VOICE ASSISTANT</span>
            <Eyebrow>Technology that speaks your language</Eyebrow>
            <h2>
              Your language. Your business. <em>Your assistant.</em>
            </h2>
            <p>
              Update your profile, find suppliers, join buying groups and post business updates
              using simple voice commands in Hindi, English, Marathi and more.
            </p>
            <div className="language-row">
              <span>हिंदी</span>
              <span>English</span>
              <span>मराठी</span>
              <span>বাংলা</span>
              <span>தமிழ்</span>
            </div>
            <Button href="#/voice">Try voice assistant</Button>
          </div>
        </div>
      </section>

      <section className="offline-section">
        <div className="container offline-layout">
          <span className="offline-icon">
            <Icon name="offline" size={30} />
          </span>
          <div>
            <Eyebrow light>Built for real India</Eyebrow>
            <h2>Stay connected even without internet.</h2>
            <p>
              Access your identity card, saved contacts, portfolio, drafts and pending updates
              offline. Everything syncs when you reconnect.
            </p>
          </div>
          <div className="sync-card">
            <span>
              <i></i> Offline mode
            </span>
            <div>
              <Icon name="identity" />
              <p>
                <strong>Digital identity</strong>
                <small>Available offline</small>
              </p>
              <Icon name="check" size={16} />
            </div>
            <div>
              <Icon name="briefcase" />
              <p>
                <strong>Portfolio photos</strong>
                <small>12 items cached</small>
              </p>
              <Icon name="check" size={16} />
            </div>
            <div>
              <Icon name="message" />
              <p>
                <strong>Pending updates</strong>
                <small>Will sync automatically</small>
              </p>
              <span>3</span>
            </div>
          </div>
        </div>
      </section>

      <section className="final-cta">
        <div className="container">
          <Eyebrow>Start building today</Eyebrow>
          <h2>
            One skill. One identity.
            <br />
            <em>A network of opportunities.</em>
          </h2>
          <p>
            Join India's growing professional community for karigars, skilled workers and small
            businesses.
          </p>
          <Button href="#/join">Create your free profile</Button>
          <small>Free to join · No technical skills required · Available in your language</small>
        </div>
      </section>
    </main>
  );
}

const professionals = [
  {
    id: "rahul",
    name: "Rahul Sharma",
    role: "Master Tailor",
    experience: "12 years",
    skills: ["Custom suits", "Alterations"],
    city: "Delhi",
    image: photos.professional,
    verified: true,
  },
  {
    id: "ayesha",
    name: "Ayesha Khan",
    role: "Home Baker",
    experience: "7 years",
    skills: ["Corporate orders", "Cakes"],
    city: "Mumbai",
    image: photos.potter,
    verified: true,
  },
  {
    id: "meera",
    name: "Meera Patil",
    role: "Textile Designer",
    experience: "9 years",
    skills: ["Handloom", "Natural dyes"],
    city: "Pune",
    image: photos.weaver,
    verified: true,
  },
  {
    id: "suresh",
    name: "Suresh Kumar",
    role: "Fabric Supplier",
    experience: "18 years",
    skills: ["Cotton", "Bulk supply"],
    city: "Delhi",
    image: photos.tailor,
    verified: true,
  },
  {
    id: "priya",
    name: "Priya Verma",
    role: "Jewellery Artisan",
    experience: "6 years",
    skills: ["Silver", "Beadwork"],
    city: "Jaipur",
    image: photos.jewellery,
    verified: false,
  },
  {
    id: "arun",
    name: "Arun Das",
    role: "Carpenter",
    experience: "14 years",
    skills: ["Furniture", "Interiors"],
    city: "Bengaluru",
    image: photos.carpenter,
    verified: true,
  },
];

function Discover() {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("All professions");
  const [connected, setConnected] = useState<string[]>([]);
  const results = professionals.filter(
    (p) =>
      `${p.name} ${p.role} ${p.skills.join(" ")} ${p.city}`
        .toLowerCase()
        .includes(query.toLowerCase()) &&
      (filter === "All professions" || p.role.includes(filter)),
  );
  return (
    <main className="page-bg">
      <PageHero
        eyebrow="Professional directory"
        title={
          <>
            Discover people who can <em>move your business forward.</em>
          </>
        }
        text="Find verified artisans, suppliers, manufacturers and small business owners across India."
      />
      <section className="directory-section container">
        <div className="search-panel">
          <label>
            <Icon name="search" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by name, skill or business"
            />
          </label>
          <label>
            <Icon name="location" />
            <input placeholder="City or location" />
          </label>
          <button className="button primary">Search network</button>
        </div>
        <div className="directory-layout">
          <aside className="filter-panel">
            <strong>FILTER PROFESSIONALS</strong>
            <label>
              Profession
              <select value={filter} onChange={(e) => setFilter(e.target.value)}>
                <option>All professions</option>
                <option>Master Tailor</option>
                <option>Home Baker</option>
                <option>Textile Designer</option>
                <option>Fabric Supplier</option>
                <option>Jewellery Artisan</option>
                <option>Carpenter</option>
              </select>
            </label>
            <label>
              Experience
              <select>
                <option>Any experience</option>
                <option>5+ years</option>
                <option>10+ years</option>
              </select>
            </label>
            <label>
              Business type
              <select>
                <option>All businesses</option>
                <option>Artisan</option>
                <option>Supplier</option>
                <option>Manufacturer</option>
              </select>
            </label>
            <label className="check-filter">
              <input type="checkbox" /> Verified profiles only
            </label>
          </aside>
          <div className="directory-results">
            <div className="results-head">
              <strong>{results.length} professionals found</strong>
              <span>
                Sort: Recommended <Icon name="chevron" size={13} />
              </span>
            </div>
            <div className="professional-grid">
              {results.map((p) => (
                <article className="professional-card" key={p.id}>
                  <div className="pro-cover">
                    <img src={p.image} alt={`${p.name}, ${p.role}`} />
                    <span className="availability">
                      <i></i> Available
                    </span>
                  </div>
                  <div className="pro-info">
                    <div className="pro-title">
                      <h3>
                        {p.name}{" "}
                        {p.verified && (
                          <span>
                            <Icon name="check" size={11} />
                          </span>
                        )}
                      </h3>
                      <p>
                        {p.role} · {p.experience}
                      </p>
                    </div>
                    <small>
                      <Icon name="location" size={13} /> {p.city}
                    </small>
                    <div className="skill-tags">
                      {p.skills.map((s) => (
                        <span key={s}>{s}</span>
                      ))}
                    </div>
                    <div className="pro-actions">
                      <button
                        className={connected.includes(p.id) ? "connected" : ""}
                        onClick={() =>
                          setConnected((x) =>
                            x.includes(p.id) ? x.filter((i) => i !== p.id) : [...x, p.id],
                          )
                        }
                      >
                        {connected.includes(p.id) ? (
                          <>
                            <Icon name="check" size={15} /> Connected
                          </>
                        ) : (
                          <>
                            <Icon name="plus" size={15} /> Connect
                          </>
                        )}
                      </button>
                      <a href={`#/profile/${p.id}`}>View profile</a>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}

function PageHero({
  eyebrow,
  title,
  text,
  actions,
}: {
  eyebrow: string;
  title: React.ReactNode;
  text: string;
  actions?: React.ReactNode;
}) {
  return (
    <section className="page-hero">
      <div className="container">
        <Eyebrow>{eyebrow}</Eyebrow>
        <h1>{title}</h1>
        <p>{text}</p>
        {actions}
      </div>
    </section>
  );
}

type Post = {
  id: number;
  name: string;
  role: string;
  image: string;
  text: string;
  tag: string;
  media?: string;
  likes: number;
  comments: number;
};
const initialPosts: Post[] = [
  {
    id: 1,
    name: "Rahul Sharma",
    role: "Master Tailor · Delhi · 2h",
    image: photos.professional,
    text: "Looking for a reliable fabric supplier in Delhi for regular bulk purchases. Requirement: premium cotton and linen, approximately 200 metres monthly.",
    tag: "Supplier required",
    likes: 18,
    comments: 6,
  },
  {
    id: 2,
    name: "Ayesha Khan",
    role: "Home Baker · Mumbai · 5h",
    image: photos.potter,
    text: "Completed an order of 500 customised cupcakes for a corporate event. Proud of my small team for delivering everything fresh and on time.",
    tag: "Project completed",
    media:
      "https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=1000&q=85",
    likes: 94,
    comments: 21,
  },
  {
    id: 3,
    name: "Suresh Textiles",
    role: "Fabric Supplier · Delhi · 1d",
    image: photos.tailor,
    text: "Looking to connect with local tailors interested in wholesale fabric purchasing. New cotton collection now available for group orders.",
    tag: "Business opportunity",
    likes: 42,
    comments: 15,
  },
];

function NetworkPage() {
  const [posts, setPosts] = useState(initialPosts);
  const [liked, setLiked] = useState<number[]>([]);
  const [commenting, setCommenting] = useState<number | null>(null);
  const [connected, setConnected] = useState(false);
  const toggleLike = (id: number) => {
    setLiked((x) => (x.includes(id) ? x.filter((i) => i !== id) : [...x, id]));
    setPosts((x) =>
      x.map((p) => (p.id === id ? { ...p, likes: p.likes + (liked.includes(id) ? -1 : 1) } : p)),
    );
  };
  return (
    <main className="app-page">
      <div className="container app-grid">
        <aside className="network-profile panel">
          <img className="network-cover" src={photos.weaver} alt="" />
          <img className="network-avatar" src={photos.professional} alt="Rahul Sharma" />
          <h3>Rahul Sharma</h3>
          <p>Master Tailor · Delhi</p>
          <span>12 years of experience</span>
          <div>
            <a href="#/profile/rahul">
              <b>128</b>
              <small>Profile views</small>
            </a>
            <a href="#/network">
              <b>246</b>
              <small>Connections</small>
            </a>
          </div>
          <a className="profile-link" href="#/profile/rahul">
            View my profile <Icon name="arrow" size={15} />
          </a>
        </aside>
        <section className="feed">
          <div className="create-post panel">
            <img src={photos.professional} alt="" />
            <button onClick={() => setCommenting(0)}>
              Share a business update or requirement...
            </button>
            <div>
              <span>
                <Icon name="briefcase" size={17} /> Project
              </span>
              <span>
                <Icon name="connect" size={17} /> Requirement
              </span>
              <span>
                <Icon name="star" size={17} /> Achievement
              </span>
            </div>
            {commenting === 0 && (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  setCommenting(null);
                }}
              >
                <textarea
                  autoFocus
                  placeholder="What would you like your professional network to know?"
                />
                <button className="button primary">Publish update</button>
              </form>
            )}
          </div>
          <div className="feed-filter">
            <strong>Business feed</strong>
            <span>
              Most relevant <Icon name="chevron" size={13} />
            </span>
          </div>
          {posts.map((post) => (
            <article className="feed-post panel" key={post.id}>
              <header>
                <img src={post.image} alt="" />
                <div>
                  <strong>
                    {post.name}{" "}
                    <i>
                      <Icon name="check" size={10} />
                    </i>
                  </strong>
                  <small>{post.role}</small>
                </div>
                <button>•••</button>
              </header>
              <p>{post.text}</p>
              <span className="business-tag">{post.tag}</span>
              {post.media && (
                <img className="post-media" src={post.media} alt="Completed custom cupcake order" />
              )}
              <div className="engagement">
                <span>
                  <b>
                    <Icon name="like" size={12} />
                  </b>{" "}
                  {post.likes} professionals
                </span>
                <span>{post.comments} comments</span>
              </div>
              <div className="feed-actions">
                <button
                  className={liked.includes(post.id) ? "liked" : ""}
                  onClick={() => toggleLike(post.id)}
                >
                  <Icon name="like" size={18} /> Like
                </button>
                <button onClick={() => setCommenting(commenting === post.id ? null : post.id)}>
                  <Icon name="comment" size={18} /> Comment
                </button>
                <button onClick={() => alert("Post link copied for sharing.")}>
                  <Icon name="share" size={18} /> Share
                </button>
                <button>
                  <Icon name="message" size={18} /> Message
                </button>
              </div>
              {commenting === post.id && (
                <form
                  className="comment-form"
                  onSubmit={(e) => {
                    e.preventDefault();
                    setCommenting(null);
                    setPosts((x) =>
                      x.map((p) => (p.id === post.id ? { ...p, comments: p.comments + 1 } : p)),
                    );
                  }}
                >
                  <img src={photos.professional} alt="" />
                  <input autoFocus required placeholder="Write a professional comment..." />
                  <button>Post</button>
                </form>
              )}
            </article>
          ))}
        </section>
        <aside className="network-side">
          <div className="panel opportunity-card">
            <div className="panel-title">
              <strong>Business opportunities</strong>
              <a href="#/discover">View all</a>
            </div>
            <span>SUPPLIER NEEDED</span>
            <h4>Organic cotton supplier</h4>
            <p>Regular requirement · Delhi NCR</p>
            <small>Posted 3 hours ago</small>
            <hr />
            <span>COLLABORATION</span>
            <h4>Furniture finishing partner</h4>
            <p>Project based · Bengaluru</p>
            <small>Posted yesterday</small>
          </div>
          <div className="panel suggestion-card">
            <div className="panel-title">
              <strong>Grow your network</strong>
              <a href="#/discover">See all</a>
            </div>
            <img src={photos.weaver} alt="" />
            <h4>Meera Patil</h4>
            <p>Textile Designer · Pune</p>
            <small>18 mutual connections</small>
            <button onClick={() => setConnected(!connected)}>
              {connected ? (
                <>
                  <Icon name="check" size={14} /> Request sent
                </>
              ) : (
                <>
                  <Icon name="plus" size={14} /> Connect
                </>
              )}
            </button>
          </div>
        </aside>
      </div>
    </main>
  );
}

function BuyingPage() {
  const [joined, setJoined] = useState(false);
  const [showCreate, setShowCreate] = useState(false);
  const qty = joined ? 375 : 350,
    percent = Math.round((qty / 500) * 100);
  const groups = [
    ["Thread & Yarn Collective", "Varanasi", "320 kg", "68%"],
    ["Baking Ingredients Group", "Mumbai", "180 kg", "45%"],
    ["Eco Packaging Supplies", "Pune", "2,400 units", "82%"],
  ];
  return (
    <main className="page-bg">
      <PageHero
        eyebrow="Collective order hub"
        title={
          <>
            Buy together. <em>Save together.</em>
          </>
        }
        text="Pool your requirements with nearby businesses, reach wholesale quantities and reduce material costs."
        actions={
          <div className="page-hero-actions">
            <button className="button primary" onClick={() => setShowCreate(true)}>
              <Icon name="plus" size={17} /> Create buying group
            </button>
            <a className="button secondary" href="#/buying">
              How group buying works
            </a>
          </div>
        }
      />
      <section className="container buying-page">
        <div className="buying-stats">
          <div>
            <span>
              <Icon name="people" />
            </span>
            <p>
              <strong>38</strong>
              <small>Active groups near you</small>
            </p>
          </div>
          <div>
            <span>
              <Icon name="wallet" />
            </span>
            <p>
              <strong>₹4.2L</strong>
              <small>Community savings</small>
            </p>
          </div>
          <div>
            <span>
              <Icon name="store" />
            </span>
            <p>
              <strong>16</strong>
              <small>Verified suppliers</small>
            </p>
          </div>
        </div>
        <article className="flagship-group panel">
          <div className="group-label">
            <span>FEATURED GROUP · DELHI</span>
            <b>Closes in 4 days</b>
          </div>
          <div className="group-main">
            <div className="group-info">
              <span className="large-material-icon">
                <Icon name="store" size={32} />
              </span>
              <div>
                <h2>Wholesale Cotton Fabric Group</h2>
                <p>Premium 60s cotton · White, pastel & printed options</p>
                <small>Created by Rahul Sharma · 3 days ago</small>
              </div>
            </div>
            <button
              className={`button ${joined ? "joined-button" : "primary"}`}
              onClick={() => setJoined(!joined)}
            >
              {joined ? (
                <>
                  <Icon name="check" /> Joined group
                </>
              ) : (
                <>
                  Join buying group <Icon name="arrow" />
                </>
              )}
            </button>
          </div>
          <div className="group-progress">
            <div>
              <span>Group progress</span>
              <strong>{percent}% complete</strong>
            </div>
            <div className="progress-track">
              <i style={{ width: `${percent}%` }}></i>
              <b style={{ left: `${percent}%` }}>{qty}m</b>
            </div>
            <div>
              <span>0m</span>
              <span>Target: 500 metres</span>
            </div>
          </div>
          <div className="group-metrics">
            <div>
              <small>CURRENT QUANTITY</small>
              <strong>{qty} metres</strong>
              <span>{joined ? "25m added by you" : "150m more needed"}</span>
            </div>
            <div>
              <small>PARTICIPANTS</small>
              <strong>{joined ? 9 : 8} tailors</strong>
              <span className="mini-avatars">
                {[photos.professional, photos.tailor, photos.weaver].map((p, i) => (
                  <img src={p} key={i} alt="" />
                ))}
                <b>+{joined ? 6 : 5}</b>
              </span>
            </div>
            <div>
              <small>WHOLESALE ESTIMATE</small>
              <strong>₹85 / metre</strong>
              <span>
                Retail: <s>₹110 / metre</s>
              </span>
            </div>
            <div className="savings-metric">
              <small>ESTIMATED SAVINGS</small>
              <strong>₹25 / metre</strong>
              <span>Potential total: ₹12,500</span>
            </div>
          </div>
          <div className="illustrative">
            Prices and savings are illustrative estimates. Final terms are confirmed with the
            supplier.
          </div>
          <div className="status-timeline">
            <div className="complete">
              <i>
                <Icon name="check" size={13} />
              </i>
              <span>
                Group created<small>12 Jun</small>
              </span>
            </div>
            <div className="active">
              <i></i>
              <span>
                Collecting quantity<small>In progress</small>
              </span>
            </div>
            <div>
              <i></i>
              <span>
                Supplier confirmation<small>Pending</small>
              </span>
            </div>
            <div>
              <i></i>
              <span>
                Payment & allocation<small>Pending</small>
              </span>
            </div>
            <div>
              <i></i>
              <span>
                Order dispatched<small>Pending</small>
              </span>
            </div>
          </div>
        </article>
        <div className="more-groups-head">
          <div>
            <h2>More buying groups near you</h2>
            <p>Join communities buying materials your business needs.</p>
          </div>
          <button onClick={() => setShowCreate(true)}>
            <Icon name="plus" /> Create request
          </button>
        </div>
        <div className="group-card-grid">
          {groups.map(([name, city, qty, pct], i) => (
            <article className="group-card panel" key={name}>
              <div>
                <span className={`group-type t${i}`}>
                  <Icon name={i === 0 ? "spark" : i === 1 ? "store" : "briefcase"} />
                </span>
                <small>
                  {city} · {i + 2} days left
                </small>
              </div>
              <h3>{name}</h3>
              <p>
                {qty} target · {5 + i * 2} participants
              </p>
              <div className="small-progress">
                <i style={{ width: pct }}></i>
              </div>
              <span>{pct} funded</span>
              <button>
                View group details <Icon name="arrow" size={15} />
              </button>
            </article>
          ))}
        </div>
      </section>
      {showCreate && (
        <Modal title="Create a buying request" close={() => setShowCreate(false)}>
          <form
            className="modal-form"
            onSubmit={(e) => {
              e.preventDefault();
              setShowCreate(false);
              alert("Your buying request has been created as a draft.");
            }}
          >
            <label>
              Material or product
              <input required placeholder="e.g. Premium cotton fabric" />
            </label>
            <div>
              <label>
                Target quantity
                <input required type="number" placeholder="500" />
              </label>
              <label>
                Unit
                <select>
                  <option>metres</option>
                  <option>kilograms</option>
                  <option>units</option>
                </select>
              </label>
            </div>
            <label>
              Location
              <input required placeholder="Your city" />
            </label>
            <label>
              Additional details
              <textarea placeholder="Quality, preferred colours, deadline..." />
            </label>
            <button className="button primary">Create draft request</button>
          </form>
        </Modal>
      )}
    </main>
  );
}

const languageData: Record<string, { command: string; response: string }> = {
  English: {
    command: "Find cotton fabric suppliers near me.",
    response:
      "I found three verified cotton fabric suppliers within 8 kilometres. Would you like to view their profiles?",
  },
  Hindi: {
    command: "Mere paas cotton fabric supplier dhundo.",
    response: "मुझे आपके पास तीन सत्यापित कपड़ा आपूर्तिकर्ता मिले हैं। क्या आप उनकी प्रोफ़ाइल देखना चाहेंगे?",
  },
  Marathi: {
    command: "Mala naveen customer shodhayche aahet.",
    response: "मला तुमच्या परिसरात दोन नवीन व्यवसाय संधी सापडल्या आहेत. तुम्हाला त्या पाहायच्या आहेत का?",
  },
  Bengali: {
    command: "আমার কাছাকাছি সরবরাহকারী খুঁজুন।",
    response: "আমি আপনার কাছাকাছি তিনজন যাচাইকৃত সরবরাহকারী পেয়েছি।",
  },
  Tamil: {
    command: "எனக்கு அருகில் சப்ளையர்களைக் கண்டறியவும்.",
    response: "உங்களுக்கு அருகில் மூன்று சரிபார்க்கப்பட்ட சப்ளையர்களைக் கண்டேன்.",
  },
  Telugu: {
    command: "నా దగ్గర సరఫరాదారులను కనుగొనండి.",
    response: "మీ సమీపంలో ముగ్గురు ధృవీకరించబడిన సరఫరాదారులను కనుగొన్నాను.",
  },
};

function VoicePage() {
  const [language, setLanguage] = useState("English");
  const [state, setState] = useState<"idle" | "listening" | "result">("idle");
  const simulate = () => {
    setState("listening");
    setTimeout(() => setState("result"), 1800);
  };
  return (
    <main>
      <section className="voice-page-hero">
        <div className="container voice-page-layout">
          <div>
            <Eyebrow light>Karigar Sahayak</Eyebrow>
            <h1>
              Your language. Your business. <em>Your assistant.</em>
            </h1>
            <p>
              Use simple voice commands to manage your professional profile, discover suppliers and
              grow your business—without navigating complex screens.
            </p>
            <div className="prototype-badge">
              <Icon name="spark" size={15} /> Interactive prototype · Voice interaction is simulated
            </div>
          </div>
          <div className="voice-interface">
            <div className="language-select">
              <Icon name="globe" size={17} />
              <label>
                Speaking in
                <select
                  value={language}
                  onChange={(e) => {
                    setLanguage(e.target.value);
                    setState("idle");
                  }}
                >
                  {Object.keys(languageData).map((l) => (
                    <option key={l}>{l}</option>
                  ))}
                </select>
              </label>
              <span>Change anytime</span>
            </div>
            <div className={`voice-center ${state}`}>
              <div className="voice-rings">
                <i></i>
                <i></i>
                <button onClick={simulate}>
                  <Icon name={state === "result" ? "check" : "mic"} size={34} />
                </button>
              </div>
              <h3>
                {state === "idle"
                  ? "Tap and speak"
                  : state === "listening"
                    ? "Listening..."
                    : "I heard you"}
              </h3>
              <p>
                {state === "idle"
                  ? `Try: “${languageData[language].command}”`
                  : state === "listening"
                    ? "Speak naturally in your preferred language."
                    : `“${languageData[language].command}”`}
              </p>
              {state === "listening" && (
                <div className="listening-wave">
                  {[18, 34, 25, 45, 29, 38, 20, 42, 26].map((h, i) => (
                    <i key={i} style={{ height: h }}></i>
                  ))}
                </div>
              )}
            </div>
            {state === "result" && (
              <div className="assistant-result">
                <span>
                  <Icon name="spark" size={18} />
                </span>
                <div>
                  <small>KARIGAR SAHAYAK</small>
                  <p>{languageData[language].response}</p>
                  <div>
                    <a href="#/discover">Confirm & view profiles</a>
                    <button onClick={() => setState("idle")}>Cancel</button>
                  </div>
                </div>
              </div>
            )}
            <div className="quick-commands">
              <small>TRY A QUICK COMMAND</small>
              <button onClick={simulate}>Update my digital profile</button>
              <button onClick={simulate}>Join a fabric buying group</button>
              <button onClick={simulate}>Post a business update</button>
            </div>
          </div>
        </div>
      </section>
      <section className="section">
        <div className="container">
          <div className="center-heading">
            <Eyebrow>One assistant, many tasks</Eyebrow>
            <h2>
              Simple words. <em>Useful action.</em>
            </h2>
            <p>
              Designed to reduce digital barriers and help every business owner get things done
              confidently.
            </p>
          </div>
          <div className="assistant-capabilities">
            {[
              ["identity", "Update your profile"],
              ["briefcase", "Add portfolio photos"],
              ["search", "Find nearby suppliers"],
              ["wallet", "Join buying groups"],
              ["network", "Post business updates"],
              ["target", "Check project progress"],
            ].map(([icon, label]) => (
              <div key={label}>
                <span>
                  <Icon name={icon as IconName} />
                </span>
                {label}
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}

function IdentityPage() {
  const [notice, setNotice] = useState("");
  const action = (text: string) => {
    setNotice(text);
    setTimeout(() => setNotice(""), 2500);
  };
  return (
    <main className="page-bg">
      <PageHero
        eyebrow="Your verified professional presence"
        title={
          <>
            One identity. <em>Every opportunity.</em>
          </>
        }
        text="Share a credible, complete picture of your skills and business with anyone, anywhere."
      />
      <section className="container identity-page">
        <div className="identity-preview-panel">
          <IdentityCard />
          <div className="identity-actions">
            <button onClick={() => action("Digital card prepared for download.")}>
              <Icon name="download" /> Download digital card
            </button>
            <button onClick={() => action("Profile link copied to clipboard.")}>
              <Icon name="share" /> Share profile
            </button>
            <button onClick={() => action("QR code prepared for download.")}>
              <Icon name="qr" /> Download QR code
            </button>
            <button onClick={() => action("Business card print preview opened.")}>
              <Icon name="briefcase" /> Print business card
            </button>
          </div>
          <small className="qr-demo-note">
            The QR code is a live demonstration and opens Rahul's sample profile in this prototype.
          </small>
        </div>
        <div className="identity-details panel">
          <div className="completion-head">
            <div>
              <span>PROFILE COMPLETION</span>
              <strong>85%</strong>
            </div>
            <div>
              <i style={{ width: "85%" }}></i>
            </div>
            <small>Add two certifications to improve trust.</small>
          </div>
          <h2>Your professional details</h2>
          <div className="detail-list">
            <div>
              <span>
                <Icon name="briefcase" />
              </span>
              <p>
                <small>PROFESSION</small>
                <strong>Master Tailor · Sharma Custom Tailoring</strong>
              </p>
            </div>
            <div>
              <span>
                <Icon name="star" />
              </span>
              <p>
                <small>SKILLS & SPECIALISATIONS</small>
                <strong>Men's tailoring, alterations, custom suits</strong>
              </p>
            </div>
            <div>
              <span>
                <Icon name="target" />
              </span>
              <p>
                <small>EXPERIENCE</small>
                <strong>12 years · 850+ completed orders</strong>
              </p>
            </div>
            <div>
              <span>
                <Icon name="location" />
              </span>
              <p>
                <small>BUSINESS LOCATION</small>
                <strong>Lajpat Nagar, New Delhi</strong>
              </p>
            </div>
            <div>
              <span>
                <Icon name="check" />
              </span>
              <p>
                <small>VERIFICATION</small>
                <strong>Mobile verified · Identity verified</strong>
              </p>
            </div>
          </div>
          <a href="#/profile/rahul" className="button primary">
            View public profile <Icon name="arrow" />
          </a>
        </div>
      </section>
      {notice && <Toast text={notice} />}
    </main>
  );
}

function ProfilePage() {
  const [connected, setConnected] = useState(false);
  const [following, setFollowing] = useState(false);
  const [message, setMessage] = useState(false);
  return (
    <main className="profile-page page-bg">
      <section className="profile-banner">
        <div className="container">
          <div className="public-avatar">
            <img src={photos.professional} alt="Rahul Sharma" />
            <span>
              <Icon name="check" size={14} />
            </span>
          </div>
        </div>
      </section>
      <section className="container profile-layout">
        <div className="profile-main">
          <div className="profile-intro panel">
            <div>
              <Eyebrow>Verified professional</Eyebrow>
              <h1>Rahul Sharma</h1>
              <h3>Master Tailor · Sharma Custom Tailoring</h3>
              <p>
                <Icon name="location" size={14} /> Lajpat Nagar, New Delhi · 246 connections
              </p>
            </div>
            <div className="public-actions">
              <button className="button primary" onClick={() => setConnected(!connected)}>
                {connected ? (
                  <>
                    <Icon name="check" /> Connected
                  </>
                ) : (
                  <>
                    <Icon name="plus" /> Connect
                  </>
                )}
              </button>
              <button className="button secondary" onClick={() => setMessage(true)}>
                <Icon name="message" /> Message
              </button>
              <button className="button secondary" onClick={() => setFollowing(!following)}>
                <Icon name={following ? "check" : "plus"} /> {following ? "Following" : "Follow"}
              </button>
            </div>
          </div>
          <div className="panel profile-about">
            <h2>About</h2>
            <p>
              Master tailor with 12 years of experience specialising in bespoke menswear, custom
              suits and precision alterations. I work with individuals, boutiques and corporate
              clients across Delhi NCR and am open to supplier partnerships and project
              collaborations.
            </p>
          </div>
          <div className="panel profile-about">
            <h2>Skills & endorsements</h2>
            <div className="endorsement">
              <span>
                Custom suits<small>Endorsed by 42 professionals</small>
              </span>
              <b>42</b>
            </div>
            <div className="endorsement">
              <span>
                Men's tailoring<small>Endorsed by 37 professionals</small>
              </span>
              <b>37</b>
            </div>
            <div className="endorsement">
              <span>
                Alterations<small>Endorsed by 29 professionals</small>
              </span>
              <b>29</b>
            </div>
          </div>
          <div className="panel profile-about">
            <h2>Work portfolio</h2>
            <div className="portfolio-grid">
              <img src={photos.tailor} alt="Tailoring portfolio" />
              <img src={photos.weaver} alt="Textile portfolio" />
              <img src={photos.professional} alt="Professional at work" />
            </div>
          </div>
        </div>
        <aside>
          <div className="panel profile-qr">
            <h3>Scan professional identity</h3>
            <QRCode size={150} />
            <p>KC-DL-04821</p>
            <small>Verified on KARIGAR CONNECT</small>
          </div>
          <div className="panel open-to">
            <h3>Open to</h3>
            <span>
              <Icon name="check" /> Supplier partnerships
            </span>
            <span>
              <Icon name="check" /> Bulk tailoring orders
            </span>
            <span>
              <Icon name="check" /> Training opportunities
            </span>
          </div>
        </aside>
      </section>
      {message && <MessageDrawer close={() => setMessage(false)} />}
    </main>
  );
}

function Dashboard({ online }: { online: boolean }) {
  const nav = [
    ["dashboard", "My Dashboard"],
    ["identity", "My Digital Identity"],
    ["identity", "My QR Code"],
    ["network", "Professional Network"],
    ["network", "Business Feed"],
    ["buying", "Collective Buying"],
    ["messages", "Messages"],
    ["voice", "Voice Assistant"],
    ["settings", "Settings"],
  ];
  return (
    <main className="dashboard-page">
      <div className="container dashboard-layout">
        <aside className="dash-sidebar panel">
          <div className="dash-user">
            <img src={photos.professional} alt="Rahul Sharma" />
            <div>
              <strong>Rahul Sharma</strong>
              <small>Master Tailor · Delhi</small>
            </div>
          </div>
          <nav>
            {nav.map(([route, label], i) => (
              <a key={label} href={`#/${route}`} className={i === 0 ? "active" : ""}>
                <Icon
                  name={
                    [
                      "dashboard",
                      "identity",
                      "qr",
                      "network",
                      "briefcase",
                      "wallet",
                      "message",
                      "voice",
                      "settings",
                    ][i] as IconName
                  }
                />
                {label}
              </a>
            ))}
          </nav>
        </aside>
        <div className="dash-content">
          <div className="dash-greeting">
            <div>
              <Eyebrow>Tuesday, 18 June</Eyebrow>
              <h1>Namaste, Rahul.</h1>
              <p>Here is what is happening in your professional network today.</p>
            </div>
            <span className={online ? "online-state" : "offline-state"}>
              <i></i>
              {online ? "All updates synced" : "Working offline · 3 pending updates"}
            </span>
          </div>
          <div className="dash-metrics">
            <div>
              <span>
                <Icon name="user" />
              </span>
              <p>
                <strong>85%</strong>
                <small>Profile completion</small>
              </p>
              <i>
                <b style={{ width: "85%" }}></b>
              </i>
            </div>
            <div>
              <span>
                <Icon name="target" />
              </span>
              <p>
                <strong>128</strong>
                <small>Profile views</small>
              </p>
              <em>+18% this week</em>
            </div>
            <div>
              <span>
                <Icon name="people" />
              </span>
              <p>
                <strong>7</strong>
                <small>Connection requests</small>
              </p>
              <a href="#/network">Review</a>
            </div>
            <div>
              <span>
                <Icon name="briefcase" />
              </span>
              <p>
                <strong>4</strong>
                <small>Business opportunities</small>
              </p>
              <a href="#/network">Explore</a>
            </div>
          </div>
          <div className="dash-columns">
            <section>
              <div className="panel active-order">
                <div className="panel-title">
                  <strong>Active collective order</strong>
                  <a href="#/buying">View details</a>
                </div>
                <span>Wholesale Cotton Fabric</span>
                <h3>350m of 500m collected</h3>
                <div className="small-progress">
                  <i style={{ width: "70%" }}></i>
                </div>
                <div>
                  <span>
                    <b>70%</b> complete
                  </span>
                  <span>8 participants · 4 days left</span>
                </div>
              </div>
              <div className="panel recent-activity">
                <div className="panel-title">
                  <strong>Recent activity</strong>
                  <a href="#/notifications">View all</a>
                </div>
                {[
                  ["connect", "Suresh Kumar accepted your connection request.", "20 min"],
                  ["like", "Meera Patil endorsed you for Custom Tailoring.", "2 hrs"],
                  ["wallet", "Your buying group reached 70% of its target.", "5 hrs"],
                  ["message", "New message from Ayesha Khan.", "Yesterday"],
                ].map(([icon, text, time]) => (
                  <div key={text}>
                    <span>
                      <Icon name={icon as IconName} />
                    </span>
                    <p>
                      {text}
                      <small>{time}</small>
                    </p>
                  </div>
                ))}
              </div>
            </section>
            <aside>
              <div className="panel suggested-list">
                <div className="panel-title">
                  <strong>Suggested professionals</strong>
                  <a href="#/discover">See all</a>
                </div>
                {professionals.slice(2, 5).map((p) => (
                  <div key={p.id}>
                    <img src={p.image} alt="" />
                    <p>
                      <strong>{p.name}</strong>
                      <small>
                        {p.role} · {p.city}
                      </small>
                    </p>
                    <button>
                      <Icon name="plus" size={14} />
                    </button>
                  </div>
                ))}
              </div>
              <div className="panel nearby-suppliers">
                <div className="panel-title">
                  <strong>Nearby suppliers</strong>
                </div>
                <p>
                  <Icon name="location" /> 3 verified fabric suppliers within 8 km
                </p>
                <a href="#/discover">
                  View on directory <Icon name="arrow" size={14} />
                </a>
              </div>
            </aside>
          </div>
        </div>
      </div>
    </main>
  );
}

function JoinPage({ complete }: { complete: () => void }) {
  const [step, setStep] = useState(1);
  const [account, setAccount] = useState("Artisan / Skilled Worker");
  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (step < 3) setStep(step + 1);
    else {
      complete();
      window.location.hash = "/dashboard";
    }
  };
  return (
    <main className="join-page">
      <aside className="join-brand">
        <Logo light />
        <div>
          <Eyebrow light>Join India's skill network</Eyebrow>
          <h1>Turn your experience into a professional identity.</h1>
          <p>Connect with businesses, suppliers and opportunities designed around your growth.</p>
        </div>
        <span>One Skill. One Identity. A Network of Opportunities.</span>
      </aside>
      <section className="join-form-wrap">
        <div className="join-mobile-logo">
          <Logo />
        </div>
        <div className="join-form">
          <div className="step-indicator">
            {[1, 2, 3].map((s) => (
              <span key={s} className={step >= s ? "active" : ""}>
                <i>{step > s ? <Icon name="check" size={12} /> : s}</i>
                <small>{["Account", "Your details", "Verify"][s - 1]}</small>
              </span>
            ))}
          </div>
          <form onSubmit={submit}>
            {step === 1 && (
              <>
                <span className="form-eyebrow">STEP 1 OF 3</span>
                <h2>How will you use Karigar Connect?</h2>
                <p>Choose the option that best describes you. You can update this later.</p>
                <div className="account-types">
                  {[
                    "Artisan / Skilled Worker",
                    "Supplier / Manufacturer",
                    "Small Business Owner",
                    "Customer / Business Explorer",
                  ].map((type, i) => (
                    <label key={type} className={account === type ? "selected" : ""}>
                      <input
                        type="radio"
                        name="type"
                        value={type}
                        checked={account === type}
                        onChange={() => setAccount(type)}
                      />
                      <span>
                        <Icon name={["spark", "store", "briefcase", "search"][i] as IconName} />
                      </span>
                      <div>
                        <strong>{type}</strong>
                        <small>
                          {
                            [
                              "Showcase skills and grow your work",
                              "Reach businesses and buying groups",
                              "Build your network and source supplies",
                              "Discover and connect with professionals",
                            ][i]
                          }
                        </small>
                      </div>
                      <i>
                        <Icon name="check" size={13} />
                      </i>
                    </label>
                  ))}
                </div>
              </>
            )}
            {step === 2 && (
              <>
                <span className="form-eyebrow">STEP 2 OF 3</span>
                <h2>Tell us about your work</h2>
                <p>This information creates the foundation of your professional identity.</p>
                <div className="form-grid">
                  <label>
                    Full name
                    <input required placeholder="Your full name" />
                  </label>
                  <label>
                    Mobile number
                    <div className="phone-field">
                      <span>+91</span>
                      <input required type="tel" placeholder="98765 43210" />
                    </div>
                  </label>
                  <label>
                    Profession
                    <select required defaultValue="">
                      <option value="" disabled>
                        Select profession
                      </option>
                      <option>Tailor</option>
                      <option>Weaver</option>
                      <option>Home Baker</option>
                      <option>Carpenter</option>
                      <option>Supplier</option>
                      <option>Other</option>
                    </select>
                  </label>
                  <label>
                    Business name
                    <input placeholder="Optional" />
                  </label>
                  <label>
                    Location
                    <input required placeholder="City, State" />
                  </label>
                  <label>
                    Preferred language
                    <select>
                      <option>English</option>
                      <option>हिंदी</option>
                      <option>मराठी</option>
                      <option>বাংলা</option>
                      <option>தமிழ்</option>
                    </select>
                  </label>
                </div>
              </>
            )}
            {step === 3 && (
              <div className="otp-step">
                <span className="otp-icon">
                  <Icon name="message" size={28} />
                </span>
                <span className="form-eyebrow">STEP 3 OF 3</span>
                <h2>Verify your mobile number</h2>
                <p>
                  We sent a 4-digit code to +91 98765 43210. Use <strong>1234</strong> for this
                  prototype.
                </p>
                <div className="otp-inputs">
                  {[1, 2, 3, 4].map((x, i) => (
                    <input
                      key={x}
                      required
                      maxLength={1}
                      inputMode="numeric"
                      defaultValue={i === 0 ? "1" : i === 1 ? "2" : i === 2 ? "3" : "4"}
                    />
                  ))}
                </div>
                <button type="button" className="resend">
                  Resend code in 00:28
                </button>
              </div>
            )}
            <div className="form-navigation">
              {step > 1 && (
                <button type="button" className="back-button" onClick={() => setStep(step - 1)}>
                  Back
                </button>
              )}
              <button className="button primary" type="submit">
                {step === 3 ? "Verify & create profile" : "Continue"}{" "}
                <Icon name="arrow" size={17} />
              </button>
            </div>
          </form>
        </div>
      </section>
    </main>
  );
}

function LoginPage({ complete }: { complete: () => void }) {
  const submit = (e: FormEvent) => {
    e.preventDefault();
    complete();
    window.location.hash = "/dashboard";
  };
  return (
    <main className="login-page">
      <div className="login-visual">
        <Logo light />
        <div>
          <Eyebrow light>Welcome back</Eyebrow>
          <h1>Your network is waiting.</h1>
          <p>Continue building your identity, connections and business.</p>
        </div>
        <small>Connecting India's Skills to Opportunities.</small>
      </div>
      <div className="login-form">
        <div>
          <h2>Log in to your account</h2>
          <p>Use the demo details below to access your dashboard.</p>
          <form onSubmit={submit}>
            <label>
              Mobile number
              <div className="phone-field">
                <span>+91</span>
                <input required defaultValue="98765 43210" />
              </div>
            </label>
            <label>
              4-digit PIN
              <input required type="password" defaultValue="1234" />
            </label>
            <button className="button primary">
              Log in securely <Icon name="arrow" />
            </button>
          </form>
          <small>
            New to KARIGAR CONNECT? <a href="#/join">Create your free profile</a>
          </small>
        </div>
      </div>
    </main>
  );
}

function AboutPage() {
  return (
    <main>
      <PageHero
        eyebrow="Our purpose"
        title={
          <>
            Empowering the people behind <em>India's economy.</em>
          </>
        }
        text="We believe every skilled professional deserves recognition, connection and the power to grow on their own terms."
      />
      <section className="section about-section">
        <div className="container about-layout">
          <div className="about-photo">
            <img src={photos.weaver} alt="Indian artisan working with textile" />
            <span>
              <strong>One vision</strong>Connecting India's skills to opportunities.
            </span>
          </div>
          <div>
            <Eyebrow>Why we exist</Eyebrow>
            <h2>
              Skill creates value.
              <br />
              <em>Connection unlocks it.</em>
            </h2>
            <p>
              Millions of artisans, workers and small business owners power India's local economy,
              yet their professional reputation often lives only in word of mouth. KARIGAR CONNECT
              gives that skill a visible identity and connects it to a nationwide business network.
            </p>
            <p>
              By combining digital identity, trusted professional connections, collective purchasing
              power and multilingual assistance, we help informal businesses participate confidently
              in the digital economy.
            </p>
            <div className="about-values">
              <span>
                <strong>Identity</strong>Recognition for real skill
              </span>
              <span>
                <strong>Network</strong>Trust through connection
              </span>
              <span>
                <strong>Growth</strong>Opportunity shared fairly
              </span>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}

function SimpleInbox({ notifications = false }: { notifications?: boolean }) {
  return (
    <main className="page-bg">
      <PageHero
        eyebrow={notifications ? "Stay informed" : "Professional communication"}
        title={
          notifications ? (
            <>
              Your <em>notifications.</em>
            </>
          ) : (
            <>
              Messages that <em>move work forward.</em>
            </>
          )
        }
        text={
          notifications
            ? "Updates from your professional network and business activity."
            : "Talk directly with suppliers, collaborators and customers."
        }
      />
      <section className="container simple-list panel">
        {(notifications
          ? [
              ["people", "Suresh Kumar accepted your connection request", "20 minutes ago"],
              ["wallet", "Wholesale Cotton Fabric group reached 70%", "5 hours ago"],
              ["star", "Meera endorsed your Custom Tailoring skill", "Yesterday"],
            ]
          : [
              ["message", "Suresh Kumar", "I can share our latest wholesale cotton catalogue."],
              ["message", "Ayesha Khan", "Thank you for the introduction to Meera."],
              ["message", "Karigar Support", "Your digital identity is now verified."],
            ]
        ).map(([icon, title, text]) => (
          <div key={title}>
            <span>
              <Icon name={icon as IconName} />
            </span>
            <p>
              <strong>{title}</strong>
              <small>{text}</small>
            </p>
            <button>
              <Icon name="chevron" />
            </button>
          </div>
        ))}
      </section>
    </main>
  );
}

function Modal({
  title,
  close,
  children,
}: {
  title: string;
  close: () => void;
  children: React.ReactNode;
}) {
  return (
    <div className="modal-backdrop" role="dialog" aria-modal="true">
      <div className="modal">
        <header>
          <h2>{title}</h2>
          <button onClick={close}>
            <Icon name="close" />
          </button>
        </header>
        {children}
      </div>
    </div>
  );
}
function Toast({ text }: { text: string }) {
  return (
    <div className="toast">
      <Icon name="check" />
      {text}
    </div>
  );
}
function MessageDrawer({ close }: { close: () => void }) {
  return (
    <div className="message-drawer">
      <header>
        <div>
          <img src={photos.professional} alt="" />
          <span>
            <strong>Rahul Sharma</strong>
            <small>
              <i></i> Available
            </small>
          </span>
        </div>
        <button onClick={close}>
          <Icon name="close" />
        </button>
      </header>
      <div className="messages-body">
        <span>Today</span>
        <p>Hello! Thank you for reaching out. How can I help with your tailoring requirement?</p>
      </div>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          close();
        }}
      >
        <input required placeholder="Write a message..." />
        <button>
          <Icon name="arrow" />
        </button>
      </form>
    </div>
  );
}

function Footer() {
  return (
    <footer>
      <div className="container footer-grid">
        <div>
          <Logo light />
          <p>
            Your Skills. Your Identity.
            <br />
            Your Network. Your Growth.
          </p>
          <span className="footer-vision">Connecting India's Skills to Opportunities.</span>
        </div>
        <div>
          <strong>PLATFORM</strong>
          <a href="#/discover">Discover Professionals</a>
          <a href="#/identity">Digital Identity</a>
          <a href="#/network">B2B Networking</a>
          <a href="#/buying">Collective Buying</a>
        </div>
        <div>
          <strong>SUPPORT</strong>
          <a href="#/voice">Voice Assistant</a>
          <a href="#/about">About us</a>
          <a href="#/messages">Contact</a>
          <a href="#/about">Help centre</a>
        </div>
        <div>
          <strong>LEGAL</strong>
          <a href="#/about">Privacy Policy</a>
          <a href="#/about">Terms of Use</a>
          <a href="#/about">Community Standards</a>
        </div>
      </div>
      <div className="container footer-bottom">
        <span>© 2025 KARIGAR CONNECT</span>
        <strong>One Skill. One Identity. A Network of Opportunities.</strong>
        <span>Made for India's skilled communities</span>
      </div>
    </footer>
  );
}

export default function App() {
  const route = useRoute();
  const [loggedIn, setLoggedIn] = useState(false);
  const [online, setOnline] = useState(true);
  const authPage = route === "login" || route === "join";
  let page: React.ReactNode = <Home />;
  if (route === "discover") page = <Discover />;
  else if (route === "network") page = <NetworkPage />;
  else if (route === "buying") page = <BuyingPage />;
  else if (route === "voice") page = <VoicePage />;
  else if (route === "identity") page = <IdentityPage />;
  else if (route.startsWith("profile/")) page = <ProfilePage />;
  else if (route === "dashboard") page = <Dashboard online={online} />;
  else if (route === "join") page = <JoinPage complete={() => setLoggedIn(true)} />;
  else if (route === "login") page = <LoginPage complete={() => setLoggedIn(true)} />;
  else if (route === "about") page = <AboutPage />;
  else if (route === "messages") page = <SimpleInbox />;
  else if (route === "notifications") page = <SimpleInbox notifications />;
  else if (route === "settings") page = <Dashboard online={online} />;
  return (
    <>
      {!authPage && (
        <Header
          route={route}
          loggedIn={loggedIn}
          online={online}
          toggleOnline={() => setOnline(!online)}
        />
      )}{" "}
      {!online && !authPage && (
        <div className="offline-banner">
          <Icon name="offline" size={15} /> You're working offline. Saved content is available and
          changes will sync when you reconnect.
        </div>
      )}
      {page}
      {!authPage && <Footer />}
    </>
  );
}
